package com.wissen.InstantVendingMachine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstantVendingMachineApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstantVendingMachineApplication.class, args);
	}

}
